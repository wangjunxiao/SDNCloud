from __future__ import absolute_import


class Send:
    def __init__(self, id, url, action, type, ins_id):
        self.id = id
        self.url = url
        self.action = action
        self.type = type
        self.ins_id = ins_id


class Recv:
    def __init__(self, json_id, ins_id, content):
        self.json_id = json_id 
        self.ins_id = ins_id
        self.content = content

send_list = []
recv_list = []
thread_list = []
